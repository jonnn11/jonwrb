const button =
document.getElementById("mybutton");
button.addEventListener("click",
function() {
  window.location.href ="halaman.html";
});


